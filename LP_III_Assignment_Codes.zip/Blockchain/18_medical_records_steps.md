# Assignment 18 — Blockchain-based medical records mini project

## Suggested architecture
1. Front end: a simple web page or Remix for the lab demonstration.
2. Wallet: MetaMask identifies the patient/provider address.
3. Smart contract: `MedicalRecordRegistry.sol` stores record hash, timestamp, patient/provider addresses, and an encrypted off-chain reference.
4. Off-chain storage: store the actual encrypted medical document in a protected database or object store.
5. Integrity verification: calculate a hash of the downloaded file and compare it with `contentHash` saved on-chain.
6. Access control: the patient calls `authorizeProvider(providerAddress, true)` before that provider can add/read records for the patient.
7. Revoke access by calling `authorizeProvider(providerAddress, false)`. The patient can mark an existing record inactive with `revokeRecord(id)`.

## Deploy and test
1. Open Remix: https://remix.ethereum.org/.
2. Create `MedicalRecordRegistry.sol`, paste the code, and compile with Solidity `0.8.20` or compatible `0.8.x`.
3. Deploy to Remix VM first, or a test network using MetaMask.
4. Copy the patient's account address.
5. From the patient account, call `authorizeProvider(providerAddress, true)`.
6. As the patient or authorized provider, call `addRecord(patientAddress, contentHash, encryptedFileReference)`.
   - `contentHash` is a 32-byte hash in hex form, such as a SHA-256 hash padded/converted to bytes32 for a classroom demo.
   - `encryptedFileReference` should point to encrypted off-chain data; do not put names, diagnoses, prescriptions or plaintext records on-chain.
7. Call `getRecord(id)` from the patient or authorized provider account.
8. Revoke provider access and confirm that the provider can no longer call `getRecord`.
9. Call `revokeRecord(id)` from the patient account and inspect the event/transaction receipt.

## Important limitations
- This is a minimal educational prototype, not a production health system.
- Blockchain data is durable and may be publicly observable. Hashes and references can themselves leak information if chosen carelessly.
- Production deployment requires security review, privacy/legal review, encryption, key management, consent management, backups, and audited access-control logic.

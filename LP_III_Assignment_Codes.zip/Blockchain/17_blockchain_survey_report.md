# Assignment 17 — Survey report: Types of blockchains and real-time use cases

## 1. Public blockchain
- Open participation; transactions and state are generally publicly verifiable.
- Examples: Ethereum, Bitcoin.
- Use cases: cryptocurrency transfers, public smart contracts, tokenization, public proofs and decentralized applications.

## 2. Private blockchain
- A single organization controls participation and permissions.
- Use cases: internal audit trails, supply-chain processes within one organization, controlled enterprise workflows.
- Trade-off: more centralized governance; privacy and throughput may be easier to control.

## 3. Consortium / federated blockchain
- A group of known organizations jointly operates the network.
- Use cases: inter-bank settlement pilots, multi-company supply chains, trade finance and shared records between institutions.
- Trade-off: governance and membership rules must be agreed by the participants.

## 4. Hybrid blockchain
- Combines controlled/private data or processing with selected public verification.
- Use cases: regulated records, supply chains, certificates and systems that need both privacy and public proofs.
- Design caution: private data is not made private merely by placing it on a blockchain.

## Comparison
| Type | Who can participate? | Typical benefit | Main limitation |
|---|---|---|---|
| Public | Broad/open | Transparency and independent verification | Fees, throughput, public metadata |
| Private | One organization | Permission control and operational efficiency | Centralized control |
| Consortium | Selected organizations | Shared governance across organizations | Coordination complexity |
| Hybrid | Mixed access | Flexible disclosure and verification | More complex architecture |

## Conclusion
The appropriate blockchain type depends on trust assumptions, privacy requirements, governance, throughput and cost. A blockchain is not automatically the best solution; a conventional database may be simpler when a trusted operator already controls all participants.

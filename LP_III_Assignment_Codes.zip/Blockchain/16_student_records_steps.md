# Assignment 16 — Student data using struct, array and fallback

## Steps in Remix
1. Open https://remix.ethereum.org/ and create `StudentRecords.sol`.
2. Paste the code in `16_student_records.sol`.
3. Compile with Solidity `0.8.20` or compatible `0.8.x`.
4. Deploy on Remix VM for a quick local demonstration, or select Injected Provider - MetaMask and deploy to a test network.
5. Call `addStudent` with a unique ID, name, age and course.
6. Call `getStudentCount`; call `getStudent` with index `0` to read the first record.
7. To test `receive`, send a plain ETH transaction with empty calldata to the deployed contract (test network only).
8. To test `fallback`, send a transaction with non-empty calldata that does not match a function signature. In Remix, use low-level interaction if available.
9. Open the transaction receipt and record gas used and fee.

## Note
`receive()` handles plain ETH transfers with empty calldata; `fallback()` handles unmatched calls and can also accept ETH because it is payable. Student information on a public blockchain is visible to everyone; use fake sample data for this lab.

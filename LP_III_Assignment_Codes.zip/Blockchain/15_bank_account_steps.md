# Assignment 15 — Bank account smart contract

## Remix deployment steps
1. Open https://remix.ethereum.org/.
2. Create `CustomerBank.sol` and paste the code from `15_bank_account.sol`.
3. Open **Solidity Compiler**, choose compiler `0.8.20` or compatible `0.8.x`, and compile.
4. In MetaMask, choose a test network and ensure you have test ETH.
5. In Remix **Deploy & Run Transactions**, select **Injected Provider - MetaMask** and approve the connection.
6. Deploy `CustomerBank` and confirm the MetaMask transaction.
7. Expand the deployed contract.
8. To deposit, enter a small value in the Remix **Value** field, select `ether` as the unit, then click `deposit` and confirm.
9. Click `showBalance` to see the caller's internal balance in wei.
10. To withdraw, enter an amount in wei into `withdraw`. The caller must have enough internal balance.
11. Inspect the transaction receipt / explorer for gas used and transaction fee.

The contract tracks each address separately. This is a lab demonstration, not a real bank.

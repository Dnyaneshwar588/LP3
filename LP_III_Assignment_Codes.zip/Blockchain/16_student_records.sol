// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// Demonstrates structs, arrays, fallback and receive.
contract StudentRecords {
    struct Student {
        uint256 id;
        string name;
        uint8 age;
        string course;
    }

    Student[] private students;
    mapping(uint256 => bool) public idExists;
    uint256 public fallbackCallCount;

    event StudentAdded(uint256 indexed id, string name);
    event EtherReceived(address indexed sender, uint256 amount);
    event FallbackCalled(address indexed sender, uint256 amount, bytes data);

    function addStudent(uint256 id, string calldata name, uint8 age, string calldata course) external {
        require(!idExists[id], "Student ID already exists");
        require(bytes(name).length > 0, "Name required");
        students.push(Student(id, name, age, course));
        idExists[id] = true;
        emit StudentAdded(id, name);
    }

    function getStudent(uint256 index) external view returns (uint256, string memory, uint8, string memory) {
        require(index < students.length, "Index out of range");
        Student storage s = students[index];
        return (s.id, s.name, s.age, s.course);
    }

    function getStudentCount() external view returns (uint256) {
        return students.length;
    }

    receive() external payable {
        emit EtherReceived(msg.sender, msg.value);
    }

    fallback() external payable {
        fallbackCallCount += 1;
        emit FallbackCalled(msg.sender, msg.value, msg.data);
    }
}

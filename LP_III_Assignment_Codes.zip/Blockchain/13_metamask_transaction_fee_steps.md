# Assignment 13 — Install MetaMask and study Ether transaction fees

## Steps
1. Open the official MetaMask site: https://metamask.io/ and install the browser extension from its official store link.
2. Select **Create a new wallet**. Set a strong password.
3. Write down the Secret Recovery Phrase offline and store it securely. Never send it to anyone or enter it into a website claiming to be support.
4. Switch to a test network in MetaMask. If a test network is not visible, enable test networks in MetaMask settings (wording may vary by version).
5. Obtain test ETH from a faucet appropriate for that network. Test ETH has no real monetary value.
6. Send a small test transaction to another test account. Review the network, destination, amount, and estimated fee before confirming.
7. Open the transaction details and record: network, transaction hash, amount, gas limit, gas used, effective gas price, and fee.
8. If the wallet displays the fee in ETH, the basic relationship is: `transaction fee = gas used × effective gas price`. Network fee calculations and display can vary by chain.
9. Repeat with another transaction type (for example, a simple ETH transfer versus a contract interaction) and compare the fee.

## Observation table
| Transaction | Gas used | Gas price | Fee shown by wallet |
|---|---:|---:|---:|
| Test ETH transfer | Fill from explorer | Fill from explorer | Fill from MetaMask |
| Smart contract call | Fill from explorer | Fill from explorer | Fill from MetaMask |

## Result
MetaMask was installed and a test transaction was inspected. Actual gas and fee values depend on network conditions and the transaction; do not copy sample values as if they were observed.

// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// Educational medical-record registry. Stores only a hash and minimal metadata.
/// Keep the actual medical file encrypted and off-chain.
contract MedicalRecordRegistry {
    address public owner;
    uint256 public nextRecordId = 1;

    struct Record {
        uint256 id;
        address patient;
        address addedBy;
        bytes32 contentHash;
        string encryptedFileReference;
        uint256 createdAt;
        bool active;
    }

    mapping(uint256 => Record) private records;
    mapping(address => mapping(address => bool)) public authorizedProvider;

    event ProviderAuthorization(address indexed patient, address indexed provider, bool authorized);
    event RecordAdded(uint256 indexed id, address indexed patient, address indexed addedBy, bytes32 contentHash);
    event RecordRevoked(uint256 indexed id, address indexed patient);

    modifier onlyPatient(uint256 id) {
        require(records[id].patient == msg.sender, "Patient only");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    function authorizeProvider(address provider, bool allowed) external {
        require(provider != address(0), "Invalid provider");
        authorizedProvider[msg.sender][provider] = allowed;
        emit ProviderAuthorization(msg.sender, provider, allowed);
    }

    function addRecord(
        address patient,
        bytes32 contentHash,
        string calldata encryptedFileReference
    ) external returns (uint256 id) {
        require(patient != address(0), "Invalid patient");
        require(contentHash != bytes32(0), "Hash required");
        require(
            msg.sender == patient || authorizedProvider[patient][msg.sender],
            "Not authorized by patient"
        );
        id = nextRecordId++;
        records[id] = Record({
            id: id,
            patient: patient,
            addedBy: msg.sender,
            contentHash: contentHash,
            encryptedFileReference: encryptedFileReference,
            createdAt: block.timestamp,
            active: true
        });
        emit RecordAdded(id, patient, msg.sender, contentHash);
    }

    function getRecord(uint256 id) external view returns (
        uint256 recordId,
        address patient,
        address addedBy,
        bytes32 contentHash,
        string memory encryptedFileReference,
        uint256 createdAt,
        bool active
    ) {
        Record storage r = records[id];
        require(r.id != 0, "Record does not exist");
        require(
            msg.sender == r.patient || authorizedProvider[r.patient][msg.sender],
            "Not authorized"
        );
        return (r.id, r.patient, r.addedBy, r.contentHash,
                r.encryptedFileReference, r.createdAt, r.active);
    }

    function revokeRecord(uint256 id) external onlyPatient(id) {
        require(records[id].id != 0, "Record does not exist");
        records[id].active = false;
        emit RecordRevoked(id, msg.sender);
    }
}

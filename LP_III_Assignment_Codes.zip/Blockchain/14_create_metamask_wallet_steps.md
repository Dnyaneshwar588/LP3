# Assignment 14 — Create a MetaMask wallet

## Steps
1. Visit https://metamask.io/ and install MetaMask from its official download flow.
2. Open the extension and select **Create a new wallet**.
3. Set a strong wallet password and accept the setup prompts.
4. Reveal the Secret Recovery Phrase and write it down offline in the correct order.
5. Confirm the phrase when prompted. Store it safely; anyone with it can control the wallet.
6. Copy your public wallet address to receive test ETH. Never share the recovery phrase or private key.
7. Switch to the lab test network and use a trusted faucet to request test ETH if required.
8. Send a small test transaction and verify it in the network explorer.
9. Record the public address and transaction hash in your practical journal, but never record the password or recovery phrase.

## Result
A MetaMask wallet was created and prepared for test-network transactions.

"""Assignment 7: Uber fare prediction with cleaning, IQR outliers, correlation and two regressors.
Run: python 07_uber_fare_prediction.py uber.csv
Expected common columns: fare_amount, pickup_longitude, pickup_latitude,
dropoff_longitude, dropoff_latitude, passenger_count, pickup_datetime.
"""
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

path = sys.argv[1] if len(sys.argv) > 1 else "uber.csv"
df = pd.read_csv(path)
df.columns = [c.strip().lower() for c in df.columns]
target = "fare_amount"
if target not in df.columns:
    raise ValueError(f"Target '{target}' not found. Available columns: {list(df.columns)}")
df = df.drop_duplicates()
df = df[df[target].notna() & (df[target] > 0)]
for col in ["pickup_longitude", "dropoff_longitude"]:
    if col in df: df = df[df[col].between(-180, 180)]
for col in ["pickup_latitude", "dropoff_latitude"]:
    if col in df: df = df[df[col].between(-90, 90)]
if "passenger_count" in df:
    df = df[df["passenger_count"].between(1, 8)]
if "pickup_datetime" in df:
    dt = pd.to_datetime(df["pickup_datetime"], errors="coerce", utc=True)
    df["pickup_hour"] = dt.dt.hour
    df["pickup_day"] = dt.dt.day
    df["pickup_month"] = dt.dt.month
    df = df.drop(columns=["pickup_datetime"])
# IQR rule for target; remove extreme target outliers.
q1, q3 = df[target].quantile([0.25, 0.75]); iqr = q3 - q1
df = df[df[target].between(max(0, q1 - 1.5 * iqr), q3 + 1.5 * iqr)]
numeric = df.select_dtypes(include=np.number).columns.tolist()
print("Rows after cleaning:", len(df))
print("Numeric correlation with fare:\n", df[numeric].corr()[target].sort_values(ascending=False))
df[numeric].corr().to_csv("uber_correlation.csv")
if len(numeric) > 1:
    plt.figure(figsize=(9, 6)); plt.imshow(df[numeric].corr(), aspect="auto")
    plt.xticks(range(len(numeric)), numeric, rotation=90); plt.yticks(range(len(numeric)), numeric)
    plt.colorbar(); plt.title("Uber dataset correlation"); plt.tight_layout(); plt.savefig("uber_correlation.png")
X, y = df.drop(columns=[target]), df[target]
num_cols = X.select_dtypes(include=np.number).columns.tolist()
cat_cols = X.select_dtypes(exclude=np.number).columns.tolist()
preprocess = ColumnTransformer([
    ("num", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), num_cols),
    ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]), cat_cols)
])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=100, random_state=42, n_jobs=-1)
}
for name, model in models.items():
    pipe = Pipeline([("preprocess", preprocess), ("model", model)])
    pipe.fit(X_train, y_train); pred = pipe.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, pred))
    print(f"\n{name}: R2={r2_score(y_test, pred):.4f}, RMSE={rmse:.4f}, MAE={mean_absolute_error(y_test, pred):.4f}")

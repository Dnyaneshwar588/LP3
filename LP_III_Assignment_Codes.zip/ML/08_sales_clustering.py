"""Assignment 8: Elbow method + K-Means and optional hierarchical clustering."""
import sys
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA

path = sys.argv[1] if len(sys.argv) > 1 else "sales_data_sample.csv"
df = pd.read_csv(path, encoding="latin1")
# Use numeric business variables; identifiers and postal codes are not useful for distance.
num = df.select_dtypes(include="number").copy()
for c in list(num.columns):
    if num[c].nunique() <= 1 or "postal" in c.lower() or "phone" in c.lower():
        num = num.drop(columns=c)
if num.shape[1] < 1:
    raise ValueError("No usable numeric columns found in CSV.")
num = num.fillna(num.median(numeric_only=True))
scaler = StandardScaler()
X = scaler.fit_transform(num)
inertias = []
ks = range(1, min(11, len(df)))
for k in ks:
    model = KMeans(n_clusters=k, random_state=42, n_init=10).fit(X)
    inertias.append(model.inertia_)
plt.plot(list(ks), inertias, marker="o")
plt.xlabel("Number of clusters (K)"); plt.ylabel("Inertia"); plt.title("Elbow method")
plt.tight_layout(); plt.savefig("sales_elbow.png"); plt.show()
k = int(input("Choose K after inspecting the elbow plot: "))
km = KMeans(n_clusters=k, random_state=42, n_init=10)
df["KMeans_Cluster"] = km.fit_predict(X)
print(df[["KMeans_Cluster"]].value_counts().sort_index())
df.to_csv("sales_clustered.csv", index=False)
if len(df) <= 5000:
    hc = AgglomerativeClustering(n_clusters=k)
    df["Hierarchical_Cluster"] = hc.fit_predict(X)
    df.to_csv("sales_clustered.csv", index=False)
# Visualise clusters in 2D with PCA.
pca = PCA(n_components=2, random_state=42)
coords = pca.fit_transform(X)
plt.figure(figsize=(7, 5)); plt.scatter(coords[:, 0], coords[:, 1], c=df["KMeans_Cluster"], s=12)
plt.title("Sales clusters (PCA view)"); plt.xlabel("PC1"); plt.ylabel("PC2")
plt.tight_layout(); plt.savefig("sales_clusters.png"); plt.show()

"""Assignment 12: Explore Indian stock prices and model next-day return (baseline).
Run with a CSV containing Date and a price column such as Close/Adj Close.
This is an educational baseline, not financial advice.
"""
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

path = sys.argv[1] if len(sys.argv) > 1 else "stock_data.csv"
df = pd.read_csv(path)
df.columns = [c.strip() for c in df.columns]
date_col = next((c for c in df.columns if c.lower() in {"date", "timestamp"}), None)
price_col = next((c for c in df.columns if c.lower() in {"adj close", "adj_close", "close", "closing price", "price"}), None)
if not date_col or not price_col:
    raise ValueError(f"Need Date and Close/Adj Close columns. Found: {list(df.columns)}")
df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
df[price_col] = pd.to_numeric(df[price_col], errors="coerce")
df = df.dropna(subset=[date_col, price_col]).sort_values(date_col).drop_duplicates(date_col)
df["daily_return"] = df[price_col].pct_change()
df["return_lag1"] = df["daily_return"].shift(1)
df["return_lag2"] = df["daily_return"].shift(2)
df["return_lag3"] = df["daily_return"].shift(3)
df["rolling_volatility_5"] = df["daily_return"].rolling(5).std()
df = df.dropna()
plt.figure(figsize=(10, 4)); plt.plot(df[date_col], df[price_col]); plt.title("Stock price over time")
plt.xlabel("Date"); plt.ylabel("Price"); plt.tight_layout(); plt.savefig("stock_price.png"); plt.show()
features = ["return_lag1", "return_lag2", "return_lag3", "rolling_volatility_5"]
X, y = df[features], df["daily_return"]
split = int(len(df) * 0.8)
X_train, X_test, y_train, y_test = X.iloc[:split], X.iloc[split:], y.iloc[:split], y.iloc[split:]
model = RandomForestRegressor(n_estimators=150, random_state=42)
model.fit(X_train, y_train); pred = model.predict(X_test)
print(f"R2: {r2_score(y_test,pred):.4f}")
print(f"RMSE: {np.sqrt(mean_squared_error(y_test,pred)):.6f}")
print(f"MAE: {mean_absolute_error(y_test,pred):.6f}")
print("Latest predicted next-day return (rough baseline):", round(float(model.predict(X.tail(1))[0]) * 100, 4), "%")

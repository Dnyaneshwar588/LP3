"""Assignment 9: KNN on diabetes.csv with confusion matrix and classification metrics."""
import sys
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, classification_report

path = sys.argv[1] if len(sys.argv) > 1 else "diabetes.csv"
df = pd.read_csv(path)
df.columns = [c.strip() for c in df.columns]
target = next((c for c in df.columns if c.lower() in {"outcome", "diabetes", "target", "class"}), df.columns[-1])
X, y = df.drop(columns=[target]), df[target]
X = pd.get_dummies(X, drop_first=True)
X = X.apply(pd.to_numeric, errors="coerce")
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
model = Pipeline([("imputer", SimpleImputer(strategy="median")), ("scale", StandardScaler()),
                  ("knn", KNeighborsClassifier(n_neighbors=5))])
model.fit(X_train, y_train); pred = model.predict(X_test)
acc = accuracy_score(y_test, pred)
print("Target column:", target)
print("Confusion matrix:\n", confusion_matrix(y_test, pred))
print(f"Accuracy: {acc:.4f}")
print(f"Error rate: {1-acc:.4f}")
print(f"Precision: {precision_score(y_test, pred, average='weighted', zero_division=0):.4f}")
print(f"Recall: {recall_score(y_test, pred, average='weighted', zero_division=0):.4f}")
print(classification_report(y_test, pred, zero_division=0))

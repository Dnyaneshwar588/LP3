"""Assignment 10: Bank customer churn classifier using a Keras neural network."""
import sys
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.utils.class_weight import compute_class_weight
import tensorflow as tf

path = sys.argv[1] if len(sys.argv) > 1 else "Churn_Modelling.csv"
df = pd.read_csv(path)
target = next((c for c in df.columns if c.lower() in {"exited", "churn", "target"}), None)
if target is None:
    raise ValueError(f"Cannot find target Exited/Churn. Columns: {list(df.columns)}")
drop_cols = [c for c in ["RowNumber", "CustomerId", "Surname"] if c in df.columns]
X, y = df.drop(columns=[target] + drop_cols), df[target]
if y.dtype == "object":
    y = LabelEncoder().fit_transform(y)
numeric = X.select_dtypes(include=np.number).columns.tolist()
categorical = X.select_dtypes(exclude=np.number).columns.tolist()
prep = ColumnTransformer([
    ("num", Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), numeric),
    ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical)
])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
X_train = prep.fit_transform(X_train).astype(np.float32)
X_test = prep.transform(X_test).astype(np.float32)
if hasattr(X_train, "toarray"): X_train = X_train.toarray()
if hasattr(X_test, "toarray"): X_test = X_test.toarray()
classes = np.unique(y_train)
weights = compute_class_weight(class_weight="balanced", classes=classes, y=y_train)
class_weights = {int(c): float(w) for c, w in zip(classes, weights)}
model = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(X_train.shape[1],)),
    tf.keras.layers.Dense(64, activation="relu"),
    tf.keras.layers.Dropout(0.25),
    tf.keras.layers.Dense(32, activation="relu"),
    tf.keras.layers.Dropout(0.15),
    tf.keras.layers.Dense(1, activation="sigmoid")
])
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
model.fit(X_train, y_train, validation_split=0.2, epochs=30, batch_size=32,
          class_weight=class_weights, callbacks=[tf.keras.callbacks.EarlyStopping(patience=4, restore_best_weights=True)],
          verbose=1)
prob = model.predict(X_test, verbose=0).ravel()
pred = (prob >= 0.5).astype(int)
print("Accuracy:", round(accuracy_score(y_test, pred), 4))
print("Confusion matrix:\n", confusion_matrix(y_test, pred))
print(classification_report(y_test, pred, zero_division=0))

"""Assignment 11: Compare KNN and SVM on emails.csv spam classification dataset."""
import sys
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report

path = sys.argv[1] if len(sys.argv) > 1 else "emails.csv"
df = pd.read_csv(path)
cols = {c.lower().strip(): c for c in df.columns}
label_col = next((cols[c] for c in ["spam", "label", "class", "target", "v1"] if c in cols), None)
if label_col is None:
    raise ValueError(f"Cannot identify label column. Available columns: {list(df.columns)}")
text_col = next((cols[c] for c in ["text", "email", "message", "v2", "body"] if c in cols and cols[c] != label_col), None)
if text_col is None:
    text_col = next((c for c in df.columns if c != label_col and df[c].dtype == "object"), None)
if text_col is None:
    raise ValueError("Cannot identify email text column.")
data = df[[text_col, label_col]].dropna()
X = data[text_col].astype(str)
y = data[label_col]
if y.dtype == "object":
    y = y.astype(str).str.lower().map(lambda x: 1 if x in {"spam", "1", "yes", "true"} else 0)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
models = {
    "KNN": Pipeline([("tfidf", TfidfVectorizer(stop_words="english", max_features=10000)),
                     ("scale", StandardScaler(with_mean=False)),
                     ("model", KNeighborsClassifier(n_neighbors=5))]),
    "Linear SVM": Pipeline([("tfidf", TfidfVectorizer(stop_words="english", max_features=10000)),
                            ("model", LinearSVC())])
}
for name, model in models.items():
    model.fit(X_train, y_train); pred = model.predict(X_test)
    print(f"\n{name}")
    print("Confusion matrix:\n", confusion_matrix(y_test, pred))
    print(f"Accuracy={accuracy_score(y_test,pred):.4f} Precision={precision_score(y_test,pred,zero_division=0):.4f} Recall={recall_score(y_test,pred,zero_division=0):.4f} F1={f1_score(y_test,pred,zero_division=0):.4f}")
    print(classification_report(y_test, pred, zero_division=0))

"""Assignment 4: 0/1 knapsack using dynamic programming."""
def knapsack_01(values, weights, capacity):
    n = len(values)
    dp = [[0] * (capacity + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        value, weight = values[i - 1], weights[i - 1]
        for cap in range(capacity + 1):
            dp[i][cap] = dp[i - 1][cap]
            if weight <= cap:
                dp[i][cap] = max(dp[i][cap], value + dp[i - 1][cap - weight])
    selected = []
    cap = capacity
    for i in range(n, 0, -1):
        if dp[i][cap] != dp[i - 1][cap]:
            selected.append(i - 1)
            cap -= weights[i - 1]
    selected.reverse()
    return dp[n][capacity], selected

def main():
    n = int(input("Number of items: "))
    values = list(map(int, input("Enter values: ").split()))
    weights = list(map(int, input("Enter integer weights: ").split()))
    capacity = int(input("Capacity: "))
    if n != len(values) or n != len(weights) or capacity < 0 or any(w < 0 for w in weights):
        print("Invalid input.")
        return
    best, selected = knapsack_01(values, weights, capacity)
    print("Maximum value:", best)
    print("Selected item numbers (1-based):", [i + 1 for i in selected])
    print("Time: O(nW); space: O(nW), where W is capacity.")

if __name__ == "__main__":
    main()

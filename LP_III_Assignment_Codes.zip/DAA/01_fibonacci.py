"""Assignment 1: Recursive and iterative Fibonacci with time/space discussion."""
import time

def fib_recursive(n):
    if n <= 1:
        return n
    return fib_recursive(n - 1) + fib_recursive(n - 2)

def fib_iterative(n):
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

def main():
    n = int(input("Enter n (index, starting at F(0)=0): "))
    if n < 0:
        print("n must be >= 0")
        return
    start = time.perf_counter()
    print("Recursive:", fib_recursive(n))
    recursive_time = time.perf_counter() - start
    start = time.perf_counter()
    print("Iterative:", fib_iterative(n))
    iterative_time = time.perf_counter() - start
    print(f"Recursive time: {recursive_time:.8f} seconds")
    print(f"Iterative time: {iterative_time:.8f} seconds")
    print("Recursive complexity: time O(2^n), call-stack space O(n)")
    print("Iterative complexity: time O(n), auxiliary space O(1)")

if __name__ == "__main__":
    main()

"""Assignment 5: N-Queens backtracking, optionally with a pre-placed queen."""
def solve_n_queens(n, fixed=None):
    # fixed is (row, col), both zero-based; pass None for no pre-placed queen.
    if n <= 0:
        return None
    board = [-1] * n  # board[col] = row
    if fixed is not None:
        r, c = fixed
        if not (0 <= r < n and 0 <= c < n):
            return None
        board[c] = r
    def safe(row, col):
        for old_col in range(col):
            old_row = board[old_col]
            if old_row == row or abs(old_row - row) == abs(old_col - col):
                return False
        return True
    def backtrack(col):
        if col == n:
            return True
        if board[col] != -1:  # fixed queen in this column
            return safe(board[col], col) and backtrack(col + 1)
        for row in range(n):
            if safe(row, col):
                board[col] = row
                if backtrack(col + 1):
                    return True
                board[col] = -1
        return False
    if backtrack(0):
        return board
    return None

def main():
    n = int(input("Board size N (use 8 for 8-Queens): "))
    use_fixed = input("Pre-place a queen? (y/n): ").strip().lower() == "y"
    fixed = None
    if use_fixed:
        r = int(input("Queen row (1-based): ")) - 1
        c = int(input("Queen column (1-based): ")) - 1
        fixed = (r, c)
    solution = solve_n_queens(n, fixed)
    if solution is None:
        print("No solution for this placement.")
        return
    for r in range(n):
        print(" ".join("Q" if solution[c] == r else "." for c in range(n)))
    print("One solution found. Rows by column (1-based):", [r + 1 for r in solution])

if __name__ == "__main__":
    main()

"""Assignment 2: Huffman encoding using a greedy min-heap."""
import heapq
from collections import Counter
from itertools import count

class Node:
    def __init__(self, freq, char=None, left=None, right=None):
        self.freq, self.char, self.left, self.right = freq, char, left, right
    def __lt__(self, other):
        return self.freq < other.freq

def huffman_codes(text):
    if not text:
        return {}
    frequencies = Counter(text)
    serial = count()
    heap = [(freq, next(serial), Node(freq, char)) for char, freq in frequencies.items()]
    heapq.heapify(heap)
    if len(heap) == 1:
        return {heap[0][2].char: "0"}
    while len(heap) > 1:
        f1, _, left = heapq.heappop(heap)
        f2, _, right = heapq.heappop(heap)
        parent = Node(f1 + f2, None, left, right)
        heapq.heappush(heap, (parent.freq, next(serial), parent))
    root = heap[0][2]
    codes = {}
    def walk(node, prefix):
        if node.char is not None:
            codes[node.char] = prefix or "0"
            return
        walk(node.left, prefix + "0")
        walk(node.right, prefix + "1")
    walk(root, "")
    return codes

def main():
    text = input("Enter text to encode: ")
    codes = huffman_codes(text)
    encoded = "".join(codes[ch] for ch in text)
    print("Character frequencies and codes:")
    for ch, code in sorted(codes.items()):
        print(repr(ch), "frequency =", text.count(ch), "code =", code)
    print("Encoded bit string:", encoded)
    print("Original size (8-bit characters):", len(text) * 8, "bits")
    print("Encoded size:", len(encoded), "bits")

if __name__ == "__main__":
    main()

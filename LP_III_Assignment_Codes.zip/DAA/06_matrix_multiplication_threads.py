"""Assignment 6: standard and threaded matrix multiplication; one thread per row."""
import threading
import time
import random

def multiply_standard(A, B):
    rows, inner, cols = len(A), len(B), len(B[0])
    return [[sum(A[i][k] * B[k][j] for k in range(inner))
             for j in range(cols)] for i in range(rows)]

def multiply_threaded_rows(A, B):
    rows, inner, cols = len(A), len(B), len(B[0])
    result = [[0] * cols for _ in range(rows)]
    def calculate_row(i):
        for j in range(cols):
            result[i][j] = sum(A[i][k] * B[k][j] for k in range(inner))
    threads = [threading.Thread(target=calculate_row, args=(i,)) for i in range(rows)]
    for t in threads: t.start()
    for t in threads: t.join()
    return result

def main():
    n = int(input("Square matrix size (try 30 or 50): "))
    if n <= 0:
        print("Size must be positive."); return
    random.seed(10)
    A = [[random.randint(0, 9) for _ in range(n)] for _ in range(n)]
    B = [[random.randint(0, 9) for _ in range(n)] for _ in range(n)]
    start = time.perf_counter(); C1 = multiply_standard(A, B); t1 = time.perf_counter() - start
    start = time.perf_counter(); C2 = multiply_threaded_rows(A, B); t2 = time.perf_counter() - start
    print("Results equal:", C1 == C2)
    print(f"Standard time: {t1:.6f} sec")
    print(f"Threaded-row time: {t2:.6f} sec")
    print("Note: Python's GIL can make CPU-bound threading slower; compare measured results.")
    if n <= 5:
        print("A =", A, "\nB =", B, "\nProduct =", C1)

if __name__ == "__main__":
    main()

"""Assignment 3: Fractional knapsack using greedy value/weight ratio."""
def fractional_knapsack(values, weights, capacity):
    if len(values) != len(weights) or any(w <= 0 for w in weights) or capacity < 0:
        raise ValueError("Values/weights must match; weights > 0 and capacity >= 0.")
    items = sorted(
        [(values[i] / weights[i], values[i], weights[i], i) for i in range(len(values))],
        reverse=True
    )
    total_value, chosen = 0.0, [0.0] * len(values)
    for ratio, value, weight, original_index in items:
        if capacity <= 0:
            break
        take = min(1.0, capacity / weight)
        chosen[original_index] = take
        total_value += value * take
        capacity -= weight * take
    return total_value, chosen

def main():
    n = int(input("Number of items: "))
    values = list(map(float, input("Enter item values separated by spaces: ").split()))
    weights = list(map(float, input("Enter item weights separated by spaces: ").split()))
    capacity = float(input("Knapsack capacity: "))
    if n != len(values) or n != len(weights):
        print("Please enter exactly n values and n weights.")
        return
    maximum, fractions = fractional_knapsack(values, weights, capacity)
    print("Maximum value:", round(maximum, 2))
    print("Fraction taken for each original item:", fractions)

if __name__ == "__main__":
    main()

# LP-III Lab Manual — Complete Assignment Code Pack

The manual lists 18 assignments. This pack separates them into **DAA (1–6)**, **Machine Learning (7–12)**, and **Blockchain (13–18)**.

## Requirements

- Python 3.10+ for DAA and ML.
- Install Python packages when needed: `pip install numpy pandas matplotlib scikit-learn scipy`
- Neural-network assignment: `pip install tensorflow`
- Blockchain: browser + MetaMask + Remix IDE (https://remix.ethereum.org). Solidity contracts are in `Blockchain/`.

## Folder map

### DAA
1. Fibonacci (recursive + iterative, timing)
2. Huffman encoding
3. Fractional knapsack
4. 0/1 knapsack using dynamic programming
5. N-Queens backtracking (supports a pre-placed queen)
6. Matrix multiplication: normal + multithreaded (one thread per row), with timings

### ML
7. Uber fare prediction: preprocessing, outlier handling, correlation, Linear Regression and Random Forest, R²/RMSE/MAE
8. Sales clustering: elbow method + K-Means; optional hierarchical clustering
9. Diabetes KNN: confusion matrix, accuracy, error rate, precision, recall
10. Bank customer churn neural network: preprocessing, normalization, accuracy and confusion matrix
11. Email spam: KNN and SVM comparison
12. Indian stock data exploration and a baseline next-day return prediction

Put the downloaded dataset CSV in the same folder as the script, or pass its path as the first command-line argument. Column names vary between dataset copies, so ML scripts try common names and print useful errors if the expected columns are not found.

### Blockchain
13. MetaMask installation and Ether transaction fee study — practical steps, no code needed.
14. Create a MetaMask wallet — practical steps, no code needed.
15. Customer bank smart contract (deposit, withdraw, balance)
16. Student records smart contract (struct, array, fallback/receive)
17. Blockchain types and real-world use cases — survey report outline.
18. Medical-records blockchain mini-project — sample Solidity contract and deployment steps.

## Safety / test-network note
Use **test networks and test ETH only** for lab experiments. Never share your MetaMask Secret Recovery Phrase or private key. The sample contracts are educational, not audited production contracts. Medical records should not be stored as plaintext on a public blockchain; the sample stores a hash and minimal metadata, while actual records should be encrypted and stored off-chain with access controls.

## Run Python scripts
From a terminal in the relevant folder:
`python 01_fibonacci.py`
For ML scripts, e.g. `python 07_uber_fare_prediction.py uber.csv`.
